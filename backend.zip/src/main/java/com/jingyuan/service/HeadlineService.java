package com.jingyuan.service;

import com.jingyuan.pojo.Headline;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jingyuan.pojo.NewsPage;
import com.jingyuan.utils.Result;

/**
* @author tiger
* @description 针对表【news_headline】的数据库操作Service
* @createDate 2024-11-17 10:31:26
*/
public interface HeadlineService extends IService<Headline> {
    Result findNewsPage(NewsPage newsPage);

    Result showHeadlineDetail(int hid);

    Result publish(String token, Headline headline);

    Result findHeadlineByHid(int hid);

    Result updateHeadline(Headline headline);
}
