package com.jingyuan.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jingyuan.pojo.User;
import com.jingyuan.service.UserService;
import com.jingyuan.mapper.UserMapper;
import com.jingyuan.utils.JwtHelper;
import com.jingyuan.utils.MD5Util;
import com.jingyuan.utils.Result;
import com.jingyuan.utils.ResultCodeEnum;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
* @author tiger
* @description 针对表【news_user】的数据库操作Service实现
* @createDate 2024-11-17 10:31:26
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{
    private final UserMapper userMapper;
    private final JwtHelper jwtHelper;
    public UserServiceImpl(UserMapper userMapper, JwtHelper jwtHelper){
        this.userMapper = userMapper;
        this.jwtHelper = jwtHelper;
    }
    @Override
    public Result login(User user) {
        Map data = new HashMap<>();

        LambdaQueryWrapper<User> userLambdaQueryWrapper = new LambdaQueryWrapper<>();
        userLambdaQueryWrapper.eq(User::getUsername, user.getUsername());
        User queryUser = userMapper.selectOne(userLambdaQueryWrapper);

        if(queryUser == null){
            return Result.build(data, ResultCodeEnum.USERNAME_ERROR);
        }
        if (user.getUserPwd() != null) {
            String password = MD5Util.encrypt(user.getUserPwd());
            if (password.equals(queryUser.getUserPwd())){
                String token = jwtHelper.createToken(queryUser.getUid().longValue());
                data.put("token", token);
                return Result.ok(data);
            } else {
                return Result.build(data, ResultCodeEnum.PASSWORD_ERROR);
            }
        } else{
            return Result.build(data, ResultCodeEnum.PASSWORD_ERROR);
        }
    }

    @Override
    public Result getUserInfo(String token) {
        if(jwtHelper.isExpiration(token)){
            return Result.build(null, ResultCodeEnum.NOTLOGIN);
        }

        User user = userMapper.selectById(jwtHelper.getUserId(token));
        if(user == null){
            return Result.build(null, ResultCodeEnum.USERNAME_ERROR);
        }

        user.setUserPwd("");
        Map data = new HashMap<>();
        data.put("loginUser", user);
        return Result.ok(data);
    }

    @Override
    public Result checkUserName(String username) {
        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper();
        lambdaQueryWrapper.eq(User::getUsername, username);
        User user = userMapper.selectOne(lambdaQueryWrapper);
        if (user == null){
            return Result.ok(null);
        }
        return Result.build(null, ResultCodeEnum.USERNAME_USED);
    }

    @Override
    public Result register(User user) {
        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(User::getUsername, user.getUsername());
        long rows = userMapper.selectCount(lambdaQueryWrapper);

        if(rows > 0){
            return Result.build(null, ResultCodeEnum.USERNAME_USED);
        }
        String password = MD5Util.encrypt(user.getUserPwd());
        user.setUserPwd(password);
        userMapper.insert(user);
        return Result.ok(null);
    }

    @Override
    public Result checkLogin(String token) {
        if(jwtHelper.isExpiration(token)){
            return Result.build(null, ResultCodeEnum.NOTLOGIN);
        }
        return Result.ok(null);
    }
}




