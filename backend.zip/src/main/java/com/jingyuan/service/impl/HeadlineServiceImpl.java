package com.jingyuan.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jingyuan.pojo.Headline;
import com.jingyuan.pojo.NewsPage;
import com.jingyuan.service.HeadlineService;
import com.jingyuan.mapper.HeadlineMapper;
import com.jingyuan.utils.JwtHelper;
import com.jingyuan.utils.Result;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
* @author tiger
* @description 针对表【news_headline】的数据库操作Service实现
* @createDate 2024-11-17 10:31:26
*/
@Service
public class HeadlineServiceImpl extends ServiceImpl<HeadlineMapper, Headline>
    implements HeadlineService{
    private final HeadlineMapper headlineMapper;
    private final JwtHelper jwtHelper;
    public HeadlineServiceImpl (HeadlineMapper headlineMapper, JwtHelper jwtHelper){
        this.headlineMapper = headlineMapper;
        this.jwtHelper = jwtHelper;
    }
    @Override
    public Result findNewsPage(NewsPage newsPage) {
        IPage page = new Page(newsPage.getPageNum(), newsPage.getPageSize());
        headlineMapper.selectPage(page, newsPage);

        Map pageInfo = new HashMap();
        pageInfo.put("pageData", page.getRecords());
        pageInfo.put("pageNum", page.getCurrent());
        pageInfo.put("pageSize", page.getSize());
        pageInfo.put("totalPage", page.getPages());
        pageInfo.put("totalSize", page.getTotal());
        Map data = new HashMap();
        data.put("pageInfo", pageInfo);

        return Result.ok(data);
    }

    @Override
    public Result showHeadlineDetail(int hid) {
        Map headline = headlineMapper.selectDetail(hid);
        Map data = new HashMap();
        data.put("headline", headline);

        int views = (Integer)headline.get("pageViews") + 1;
        Headline hl = new Headline();
        hl.setHid(hid);
        hl.setPageViews(views);

        headlineMapper.updateById(hl);

        return Result.ok(data);
    }

    @Override
    public Result publish(String token, Headline headline) {
        headline.setPublisher(jwtHelper.getUserId(token).intValue());
        headline.setPageViews(0);
        headline.setCreateTime(new Date());
        headline.setUpdateTime(new Date());
        headlineMapper.insert(headline);
        return Result.ok(null);
    }

    @Override
    public Result findHeadlineByHid(int hid) {
        Headline headline = headlineMapper.selectById(hid);
        Map data = new HashMap();
        data.put("headline", headline);
        return Result.ok(data);
    }

    @Override
    public Result updateHeadline(Headline headline) {
        Headline currentHeadline = headlineMapper.selectById(headline.getHid());

        // optimistic lock, update headline's version must match current version
        // if version not match, update fail
        // if version match, update success, version auto increase
        headline.setVersion(currentHeadline.getVersion());

        headline.setUpdateTime(new Date());
        headlineMapper.updateById(headline);
        return Result.ok(null);
    }
}




