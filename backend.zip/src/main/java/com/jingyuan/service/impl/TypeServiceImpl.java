package com.jingyuan.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jingyuan.pojo.Type;
import com.jingyuan.service.TypeService;
import com.jingyuan.mapper.TypeMapper;
import com.jingyuan.utils.Result;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author tiger
* @description 针对表【news_type】的数据库操作Service实现
* @createDate 2024-11-17 10:31:26
*/
@Service
public class TypeServiceImpl extends ServiceImpl<TypeMapper, Type>
    implements TypeService{
    private final TypeMapper typeMapper;
    public TypeServiceImpl(TypeMapper typeMapper){
        this.typeMapper = typeMapper;
    }
    @Override
    public Result findAllTypes() {
        LambdaQueryWrapper<Type> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.select(Type::getTid, Type::getTname);
        List<Type> types = typeMapper.selectList(lambdaQueryWrapper);
        return Result.ok(types);
    }

}




