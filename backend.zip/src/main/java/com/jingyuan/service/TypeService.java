package com.jingyuan.service;

import com.jingyuan.pojo.Type;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jingyuan.utils.Result;

/**
* @author tiger
* @description 针对表【news_type】的数据库操作Service
* @createDate 2024-11-17 10:31:26
*/
public interface TypeService extends IService<Type> {
    Result findAllTypes();
}
