package com.jingyuan.pojo;

import lombok.Data;

/**
 * ClassName: NewsPage
 * Package: com.jingyuan.pojo
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-18 12:56 p.m.
 */
@Data
public class NewsPage {
    private String keyWords;
    private Integer type;
    private Integer pageNum = 1;
    private Integer pageSize =10;
}
