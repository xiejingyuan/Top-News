package com.jingyuan.mapper;

import com.jingyuan.pojo.Type;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author tiger
* @description 针对表【news_type】的数据库操作Mapper
* @createDate 2024-11-17 10:31:26
* @Entity com.jingyuan.pojo.Type
*/
public interface TypeMapper extends BaseMapper<Type> {

}




