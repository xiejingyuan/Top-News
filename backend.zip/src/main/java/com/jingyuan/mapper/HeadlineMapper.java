package com.jingyuan.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jingyuan.pojo.Headline;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jingyuan.pojo.NewsPage;
import com.jingyuan.utils.Result;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

/**
* @author tiger
* @description 针对表【news_headline】的数据库操作Mapper
* @createDate 2024-11-17 10:31:26
* @Entity com.jingyuan.pojo.Headline
*/
public interface HeadlineMapper extends BaseMapper<Headline> {
    IPage<Map> selectPage(IPage page, @Param("newsPage") NewsPage newsPage);
    Map selectDetail(int hid);

}




