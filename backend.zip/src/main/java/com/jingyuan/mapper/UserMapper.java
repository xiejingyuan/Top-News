package com.jingyuan.mapper;

import com.jingyuan.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author tiger
* @description 针对表【news_user】的数据库操作Mapper
* @createDate 2024-11-17 10:31:26
* @Entity com.jingyuan.pojo.User
*/
public interface UserMapper extends BaseMapper<User> {

}




