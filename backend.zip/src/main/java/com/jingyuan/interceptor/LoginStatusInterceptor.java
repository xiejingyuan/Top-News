package com.jingyuan.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jingyuan.utils.JwtHelper;
import com.jingyuan.utils.Result;
import com.jingyuan.utils.ResultCodeEnum;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * ClassName: HeadlineInterceptor
 * Package: com.jingyuan.interceptor
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-20 10:48 a.m.
 */
@Component
// add this annotation for jwtHelper injection
// interceptor's own register rely on setting in configuration class
public class LoginStatusInterceptor implements HandlerInterceptor {
    private final JwtHelper jwtHelper;
    public LoginStatusInterceptor(JwtHelper jwtHelper){
        this.jwtHelper = jwtHelper;
    }
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if(jwtHelper.isExpiration(request.getHeader("token"))){
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonResp = objectMapper.writeValueAsString(Result.build(null, ResultCodeEnum.NOTLOGIN));
            response.getWriter().print(jsonResp);
            return false;
        }
        return true;
    }
}
