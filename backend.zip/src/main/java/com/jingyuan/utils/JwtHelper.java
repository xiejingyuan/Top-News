package com.jingyuan.utils;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

/**
 * ClassName: JwtHelper
 * Package: com.jingyuan.utils
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-17 10:58 a.m.
 */
@Data
@Component
@ConfigurationProperties(prefix = "jwt.token")
public class JwtHelper {

    private long tokenExpiration; //有效时间,单位毫秒 1000毫秒 == 1秒
    private String tokenSignKey;  //当前程序签名秘钥

    //生成token字符串
    public String createToken(Long userId) {
        System.out.println("tokenExpiration = " + tokenExpiration);
        System.out.println("tokenSignKey = " + tokenSignKey);
        SecretKey signingKey = Keys.hmacShaKeyFor(tokenSignKey.getBytes());
        return Jwts.builder()
                .subject("YYGH-USER")
                .expiration(new Date(System.currentTimeMillis() + tokenExpiration * 1000 * 60)) //单位分钟
                .claim("userId", userId)
                .signWith(signingKey)
                .compressWith(Jwts.ZIP.GZIP)
                .compact();
    }


    //从token字符串获取userid
    public Long getUserId(String token) {
        if (StringUtils.isEmpty(token)) return null;
        SecretKey signingKey = Keys.hmacShaKeyFor(tokenSignKey.getBytes());
        Jws<Claims> claimsJws = Jwts.parser().verifyWith(signingKey).build().parseSignedClaims(token);
        Claims claims = claimsJws.getPayload();
        Integer userId = (Integer) claims.get("userId");
        return userId.longValue();
    }

    public  boolean isExpiration(String token){
        try {
            SecretKey signingKey = Keys.hmacShaKeyFor(tokenSignKey.getBytes());
            return Jwts.parser()
                    .verifyWith(signingKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload()
                    .getExpiration().before(new Date());
            //没有过期，有效，返回false
        }catch(Exception e) {
            //过期出现异常，返回true
            return true;
        }
    }
}