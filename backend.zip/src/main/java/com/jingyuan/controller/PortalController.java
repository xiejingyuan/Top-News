package com.jingyuan.controller;

import com.jingyuan.pojo.Headline;
import com.jingyuan.pojo.NewsPage;
import com.jingyuan.service.HeadlineService;
import com.jingyuan.service.TypeService;
import com.jingyuan.utils.Result;
import org.springframework.web.bind.annotation.*;

/**
 * ClassName: PortalController
 * Package: com.jingyuan.controller
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-18 10:39 a.m.
 */
@RestController
@RequestMapping("portal")
public class PortalController {
    private final TypeService typeService;
    private final HeadlineService headlineService;
    public PortalController(TypeService typeService, HeadlineService headlineService){
        this.typeService = typeService;
        this.headlineService = headlineService;
    }

    @GetMapping("findAllTypes")
    public Result findAllTypes(){
        return typeService.findAllTypes();
    }

    @PostMapping("findNewsPage")
    public Result findNewsPage(@RequestBody NewsPage newsPage){
        return headlineService.findNewsPage(newsPage);
    }

    @PostMapping("showHeadlineDetail")
    public Result showHeadlineDetail(@RequestParam int hid){
        return headlineService.showHeadlineDetail(hid);
    }
}
