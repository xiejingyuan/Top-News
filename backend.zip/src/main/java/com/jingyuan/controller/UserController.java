package com.jingyuan.controller;

import com.jingyuan.pojo.User;
import com.jingyuan.service.UserService;
import com.jingyuan.utils.Result;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * ClassName: UserController
 * Package: com.jingyuan.controller
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-17 3:18 p.m.
 */
@RestController
@RequestMapping("user")
@CrossOrigin
public class UserController {
    private final UserService userService;
    public UserController(UserService userService){
        this.userService = userService;
    }

    @PostMapping("login")
    public Result login(@RequestBody User user){
        return userService.login(user);
    }

    @GetMapping("getUserInfo")
    public Result getUserInfo(@RequestHeader String token){
        return userService.getUserInfo(token);
    }

    @PostMapping("checkUserName")
    public Result checkUserName(String username){
        return userService.checkUserName(username);
    }

    @PostMapping("regist")
    public Result register(@RequestBody User user){
        return userService.register(user);
    }

    @GetMapping("checkLogin")
    public Result checkLogin(@RequestHeader String token){
        return userService.checkLogin(token);
    }
}
