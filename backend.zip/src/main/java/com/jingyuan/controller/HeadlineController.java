package com.jingyuan.controller;

import com.jingyuan.pojo.Headline;
import com.jingyuan.service.HeadlineService;
import com.jingyuan.utils.Result;
import org.springframework.web.bind.annotation.*;

/**
 * ClassName: HeadlineController
 * Package: com.jingyuan.controller
 * Description:
 *
 * @author Jingyuan Xie
 * @version 1.0
 * @since 2024-11-20 10:21 a.m.
 */
@RestController
@RequestMapping("headline")
@CrossOrigin
public class HeadlineController {
    private final HeadlineService headlineService;
    public HeadlineController(HeadlineService headlineService){
        this.headlineService = headlineService;
    }

    @PostMapping("publish")
    public Result publish(@RequestHeader String token, @RequestBody Headline headline){
        return headlineService.publish(token, headline);
    }

    @PostMapping("findHeadlineByHid")
    public Result findHeadlineByHid(@RequestParam int hid){
        return headlineService.findHeadlineByHid(hid);
    }

    @PostMapping("update")
    public Result updateHeadline(@RequestBody Headline headline){
        return headlineService.updateHeadline(headline);
    }

    @PostMapping("removeByHid")
    public Result removeByHid(@RequestParam int hid){
        headlineService.removeById(hid);
        return Result.ok(null);
    }
}
